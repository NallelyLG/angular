import { Samsung } from './samsung';

describe('Samsung', () => {
  it('should create an instance', () => {
    expect(new Samsung()).toBeTruthy();
  });
});
