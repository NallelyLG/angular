import { Auto } from './auto';

describe('Auto', () => {
  it('should create an instance', () => {
    expect(new Auto()).toBeTruthy();
  });
});
