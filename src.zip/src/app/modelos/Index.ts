export * from './abarrotes';
export * from './articulo';
export * from './electronicos';
export * from './samsung';
export * from './lg';
export * from './ford';
export * from './auto';
export * from './chevrolet';