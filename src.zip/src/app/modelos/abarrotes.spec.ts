import { Abarrotes } from './abarrotes';

describe('Abarrotes', () => {
  it('should create an instance', () => {
    expect(new Abarrotes()).toBeTruthy();
  });
});
