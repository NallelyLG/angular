import { Ford } from './ford';

describe('Ford', () => {
  it('should create an instance', () => {
    expect(new Ford()).toBeTruthy();
  });
});
