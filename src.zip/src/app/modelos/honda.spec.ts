import { Honda } from './honda';

describe('Honda', () => {
  it('should create an instance', () => {
    expect(new Honda()).toBeTruthy();
  });
});
