import { Mazda } from './mazda';

describe('Mazda', () => {
  it('should create an instance', () => {
    expect(new Mazda()).toBeTruthy();
  });
});
