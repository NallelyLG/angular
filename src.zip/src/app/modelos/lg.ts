export class Lg {
}
