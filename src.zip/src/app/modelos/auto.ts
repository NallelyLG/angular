export class Auto {
    public motor: string;
    constructor(){
    }
}
