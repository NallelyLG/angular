import { Chevrolet } from './chevrolet';

describe('Chevrolet', () => {
  it('should create an instance', () => {
    expect(new Chevrolet()).toBeTruthy();
  });
});
