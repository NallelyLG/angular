import { Lg } from './lg';

describe('Lg', () => {
  it('should create an instance', () => {
    expect(new Lg()).toBeTruthy();
  });
});
