import {Auto} from './auto';
export class Ford extends Auto {
    constructor(){
        super();
        this.motor='hibrido';
    }
}
