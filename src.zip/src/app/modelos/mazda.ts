export class Mazda {
}
