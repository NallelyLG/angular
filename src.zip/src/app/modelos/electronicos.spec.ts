import { Electronicos } from './electronicos';

describe('Electronicos', () => {
  it('should create an instance', () => {
    expect(new Electronicos()).toBeTruthy();
  });
});
