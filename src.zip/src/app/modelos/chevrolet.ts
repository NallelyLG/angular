import {Auto} from './auto';
export class Chevrolet extends Auto {
    constructor(){
        super();
        this.motor='deportivo';
    }
}
