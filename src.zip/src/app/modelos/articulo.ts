export interface Articulo {

    id?: number;
    nombre:string;
    marca?:string;
    precio:number;
    imprimir?;
    title?:string;
    description?:string;
    promotion?:boolean;
    categoria?:string;
    url?: string;
    fecha?: Date;

}
