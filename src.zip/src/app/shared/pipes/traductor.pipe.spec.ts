import { TraductorPipe } from './traductor.pipe';

describe('TraductorPipe', () => {
  it('create an instance', () => {
    const pipe = new TraductorPipe();
    expect(pipe).toBeTruthy();
  });
});
