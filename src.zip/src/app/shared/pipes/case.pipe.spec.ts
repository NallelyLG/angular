import { CasePipe } from './case.pipe';

describe('CasePipe', () => {
  it('create an instance', () => {
    const pipe = new CasePipe();
    expect(pipe).toBeTruthy();
  });
});
